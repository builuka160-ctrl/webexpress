#!/usr/bin/env python3
"""Vector implant for the dental hero: molar crown + titanium abutment + screw."""
W, H = 560, 900
threads = []
y = 470
i = 0
while y < 800:
    # slanted thread ridge, narrowing as the screw tapers
    t = (y - 470) / 330.0
    half = 58 - 26 * t * t
    threads.append(
        f'<path d="M{280-half:.1f} {y:.1f} L{280+half:.1f} {y-9:.1f}" '
        f'stroke="rgba(28,44,56,.30)" stroke-width="3.2" stroke-linecap="round"/>'
        f'<path d="M{280-half:.1f} {y+3.4:.1f} L{280+half:.1f} {y-5.6:.1f}" '
        f'stroke="rgba(255,255,255,.55)" stroke-width="1.5" stroke-linecap="round"/>')
    y += 21
    i += 1

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-label="Керамическая коронка на титановом имплантате">
<defs>
  <linearGradient id="enamel" x1="0.18" y1="0" x2="0.9" y2="1">
    <stop offset="0" stop-color="#FFFFFF"/>
    <stop offset=".38" stop-color="#FAF7F1"/>
    <stop offset=".72" stop-color="#EDE6DA"/>
    <stop offset="1" stop-color="#D9D0C2"/>
  </linearGradient>
  <linearGradient id="enamelEdge" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0" stop-color="#ffffff" stop-opacity=".9"/>
    <stop offset=".5" stop-color="#ffffff" stop-opacity="0"/>
    <stop offset="1" stop-color="#B9AE9C" stop-opacity=".55"/>
  </linearGradient>
  <linearGradient id="steel" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0" stop-color="#5E6B75"/>
    <stop offset=".16" stop-color="#C9D3DA"/>
    <stop offset=".34" stop-color="#F2F6F8"/>
    <stop offset=".52" stop-color="#9FAEB9"/>
    <stop offset=".72" stop-color="#E6ECF0"/>
    <stop offset=".88" stop-color="#7C8A95"/>
    <stop offset="1" stop-color="#48555F"/>
  </linearGradient>
  <linearGradient id="collar" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0" stop-color="#6B7883"/>
    <stop offset=".2" stop-color="#EEF3F6"/>
    <stop offset=".5" stop-color="#93A2AD"/>
    <stop offset=".8" stop-color="#E4EAEE"/>
    <stop offset="1" stop-color="#5A666F"/>
  </linearGradient>
  <radialGradient id="shadow" cx=".5" cy=".5" r=".5">
    <stop offset="0" stop-color="#1D3A4D" stop-opacity=".34"/>
    <stop offset="1" stop-color="#1D3A4D" stop-opacity="0"/>
  </radialGradient>
  <filter id="soft" x="-30%" y="-30%" width="160%" height="160%">
    <feGaussianBlur stdDeviation="9"/>
  </filter>
</defs>

<ellipse cx="280" cy="846" rx="150" ry="26" fill="url(#shadow)"/>

<!-- implant screw -->
<path d="M238 470 L322 470 L306 792 Q280 822 254 792 Z" fill="url(#steel)"/>
<g clip-path="url(#screwClip)">{''.join(threads)}</g>
<clipPath id="screwClip"><path d="M238 470 L322 470 L306 792 Q280 822 254 792 Z"/></clipPath>

<!-- abutment -->
<path d="M206 372 L354 372 L330 470 L230 470 Z" fill="url(#steel)"/>
<path d="M206 372 L354 372 L349 392 L211 392 Z" fill="rgba(255,255,255,.35)"/>
<rect x="222" y="452" width="116" height="9" rx="4" fill="rgba(20,36,48,.25)"/>

<!-- collar under the crown -->
<ellipse cx="280" cy="366" rx="96" ry="20" fill="url(#collar)"/>
<path d="M184 356 Q280 396 376 356 L376 372 Q280 412 184 372 Z" fill="url(#collar)"/>

<!-- crown: molar with four cusps -->
<path d="M280 64
         C318 64 352 74 372 96
         C392 118 398 146 392 178
         C404 206 408 238 402 268
         C396 300 380 326 352 344
         C330 358 306 364 280 364
         C254 364 230 358 208 344
         C180 326 164 300 158 268
         C152 238 156 206 168 178
         C162 146 168 118 188 96
         C208 74 242 64 280 64 Z"
      fill="url(#enamel)"/>
<path d="M280 64
         C318 64 352 74 372 96
         C392 118 398 146 392 178
         C404 206 408 238 402 268
         C396 300 380 326 352 344
         C330 358 306 364 280 364
         C254 364 230 358 208 344
         C180 326 164 300 158 268
         C152 238 156 206 168 178
         C162 146 168 118 188 96
         C208 74 242 64 280 64 Z"
      fill="url(#enamelEdge)" opacity=".8"/>

<!-- cusp grooves -->
<path d="M280 92 L280 214" stroke="rgba(150,138,120,.40)" stroke-width="7" stroke-linecap="round" fill="none"/>
<path d="M186 140 Q244 176 280 214" stroke="rgba(150,138,120,.30)" stroke-width="6" stroke-linecap="round" fill="none"/>
<path d="M374 140 Q316 176 280 214" stroke="rgba(150,138,120,.30)" stroke-width="6" stroke-linecap="round" fill="none"/>
<path d="M280 214 L280 268" stroke="rgba(150,138,120,.22)" stroke-width="5" stroke-linecap="round" fill="none"/>

<!-- specular highlights -->
<path d="M214 118 Q192 168 200 226 Q206 272 226 300" stroke="rgba(255,255,255,.85)" stroke-width="22" stroke-linecap="round" fill="none" filter="url(#soft)" opacity=".75"/>
<ellipse cx="330" cy="150" rx="26" ry="42" fill="#fff" opacity=".55" filter="url(#soft)" transform="rotate(18 330 150)"/>
<path d="M186 330 Q280 372 374 330" stroke="rgba(120,108,92,.25)" stroke-width="10" fill="none" filter="url(#soft)"/>
</svg>
'''
open('/home/kali/webexpress-site/demo/dental/assets/hero-implant.svg', 'w').write(svg)
print('svg written', len(svg), 'bytes')
